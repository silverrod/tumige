using UnityEngine;
using System.Collections;

public class generator : MonoBehaviour
{
	public GameObject t;
	public GameObject obj1;
	public GameObject obj2;
	public GameObject obj3;
	public GameObject obj4;
	public GameObject obj5;
	public GUIText score;
	public GameObject particle;
	public float interval;
	private float timer;
	private bool flag;
	private bool clear;
	private float x ;
	private float y;
	private float z;
	private int sco;
	
	// Use this for initialization
	void Start ()
	{
		timer = interval;
		flag = false;
		clear = false;
		y = t.transform.position.y;
		z = 0; 
		sco = 0;
		this.score.text = sco + "cm3";
	}
	
	// Update is called once per frame
	void Update ()
	{
		timer -= Time.deltaTime;
		if (timer < 1 & flag == false & clear == false) {
			x = Random.Range (-10.0f, 10.0f);          
			Object a = Instantiate (this.particle, new Vector3 (x, y, z), Quaternion.identity);
			Destroy (a, 1.0f);
			flag = true;
		}
		if (timer < 0 & clear == false) { 
			float rand = Random.value;
			if (rand >= 0 & rand < 0.25) {
				Instantiate (this.obj1, new Vector3 (x, y, z), Quaternion.identity);
				sco = sco + 13;
				this.score.text = sco + "cm3";
			} else if (rand >= 0.25 & rand < 0.5) {
				Instantiate (this.obj2, new Vector3 (x, y, z), Quaternion.identity);
				sco = sco + 24;
				this.score.text = sco + "cm3";
			} else if (rand >= 0.5 & rand < 0.85) {
				Instantiate (this.obj3, new Vector3 (x, y, z), Quaternion.identity);
				sco = sco + 15;
				this.score.text = sco + "cm3";
			} else if (rand >= 0.85 & rand < 0.95) {
				Instantiate (this.obj4, new Vector3 (x, y, z), Quaternion.identity);
				sco = sco + 53;
				this.score.text = sco + "cm3";
			} else {
				Instantiate (this.obj5, new Vector3 (x, y, z), Quaternion.identity);
				sco = sco + 34;
				this.score.text = sco + "cm3";
			}
			timer = interval;
			flag = false;
		}
	}
	
	public void dead ()
	{
		clear = true;
	}
}
