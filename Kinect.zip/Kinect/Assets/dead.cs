using UnityEngine;
using System.Collections;

public class dead : MonoBehaviour
{
	public GUIText gameover;
	public GameObject gen;
	private float timer;
	private bool clear = false;
	
	// Use this for initialization
	void Start ()
	{
		timer = 5;
	}
	
	// Update is called once per frame
	void Update ()
	{
		if (clear == true) {
			timer -= Time.deltaTime;
			if (timer < 0) {
				Application.LoadLevel (Application.loadedLevel);
			}
		}
	}
	
	private void OnTriggerEnter (Collider other)
	{
		Debug.Log ("Enter!");
		this.gameover.text = "gameover";
		gen.SendMessage ("dead");
		clear = true;
	}
}
